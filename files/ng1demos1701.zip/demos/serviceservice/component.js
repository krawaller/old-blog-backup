var app = angular.module("serviceApp");

app.component("issuetracker",{
  template: `
    <div
      ng-repeat="issue in $ctrl.issues"
      ng-class="{done: issue.done}"
      ng-click="$ctrl.clickedIssue(issue)">{{issue.text}}</div>
    <form ng-submit="$ctrl.addNewIssue()">
      <input placeholder="Enter chore" ng-model="$ctrl.field">
      <input type="submit" value="Add new issue">
    </form>
    <pre>{{$ctrl.issues | json}}</pre>
  `,
  controller: ["issueData",function(issueData){
    var me = this;
    issueData.subscribe(function(newData){
      me.issues = newData;
    })
    this.clickedIssue = function(issue){
      issueData.toggleDone(issue.id);
    };
    this.addNewIssue = function(){
      issueData.addNewIssue(this.field);
      this.field = '';
    };
  }]
});


