
var app = angular.module("serviceApp");

app.factory("issueData",function(){
  var _issues = [
    {text: "Take out the trash",id:1},
    {text: "Do the dishes",id:2},
    {text: "Make your bed",id:3}
  ];
  var _callbacks = [];
  function notify(){
    for(var i=0;i<_callbacks.length;i++){
      _callbacks[i](angular.copy(_issues));
    }
  }
  return {
    subscribe: function(callback){
      callback(angular.copy(_issues));
      _callbacks.push(callback);
    },
    addNewIssue: function(description){
      _issues.push({
        text: description,
        id: _issues.length + 1
      });
      notify();
    },
    toggleDone: function(id){
      var idx = _issues.findIndex(function(issue){
        return issue.id === id;
      })
      if (idx > -1){
        _issues[idx].done = !_issues[idx].done;
        notify();
      }
    }
  };
});