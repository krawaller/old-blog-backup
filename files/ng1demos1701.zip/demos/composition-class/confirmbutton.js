
var app = angular.module("compositionapp"); // getter!

app.component('confirm',{
  bindings: {
    disabled: '<',
    onConfirm: '&'
  },
  controller: class ConfirmButton {
    $onInit(){
      this.mode = 'waiting'; // will be 'waiting' or 'confirm'
    }
    set disabled(newDisabled){
      if (newDisabled){
        this.mode = 'waiting';
      }
      this._disabled = newDisabled;
    }
    maybe(){
      this.mode = 'confirm';
    }
    changedmymind(){
      this.mode = 'waiting';
    }
    yesimsure(){
      this.mode = 'waiting';
      this.onConfirm(); // notifying parent
    }
  },
  template: `
    <button
      ng-if="$ctrl.mode!=='confirm'"
      ng-disabled="$ctrl._disabled"
      ng-click="$ctrl.maybe()">Submit</button>
    <span ng-if="$ctrl.mode==='confirm'">
      <button ng-click="$ctrl.yesimsure()">Confirm</button>
      <button ng-click="$ctrl.changedmymind()">Cancel</button>
    </span>
  `
});