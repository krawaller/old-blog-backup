var app = angular.module("helloworld",[]);

app.component('helloworld',{
  controller: function(){
    this.message = "Hello world from component! :D";
  },
  template: '<strong>{{$ctrl.message}}</strong>'
});
