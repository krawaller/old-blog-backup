
var app = angular.module("exercise1",[]);

app.component("issuetracker",{
  template: `
    <select
      ng-model="$ctrl.selectedSortOpt"
      ng-options="o.desc for o in $ctrl.sortOptions"></select>
    <hr>
    Filter term: <input ng-model="$ctrl.filterTerm">
    <hr>
    <div
      ng-repeat="issue in $ctrl.issues | filter : {text:$ctrl.filterTerm} | orderBy : $ctrl.selectedSortOpt.sortProp : $ctrl.selectedSortOpt.reverse "
      ng-class="{done: issue.done}"
      ng-click="$ctrl.clickedIssue(issue)">{{issue.text}} ({{issue.chore}})</div>
    <form ng-submit="$ctrl.addNewIssue()">
      <input placeholder="Enter chore" ng-model="$ctrl.field">
      <input type="submit" value="Add new issue">
    </form>
  `,
  controller: function(){
    this.issues = [
      {text: "Take out the trash", chore: 3},
      {text: "Do the dishes", chore: 1},
      {text: "Make your bed", chore: 10}
    ];
    this.sortOptions = [
      {desc: 'Sort by description (ascending)', sortProp: 'text'},
      {desc: 'Sort by description (descending)', sortProp: 'text', reverse: true},
      {desc: 'Sort by chore (ascending)', sortProp: 'chore'},
      {desc: 'Sort by chore (descending)', sortProp: 'chore', reverse: true}
    ];
    this.selectedSortOpt = this.sortOptions[0];
    this.clickedIssue = function(issue){
      issue.done = !issue.done;
    };
    this.addNewIssue = function(){
      this.issues.push({
        text: this.field
      });
      this.field = '';
    };
  }
});


