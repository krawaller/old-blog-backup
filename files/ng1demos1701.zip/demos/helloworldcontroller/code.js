var app = angular.module("helloworld",[]);

app.controller("HelloWorldController",function(){
  this.message = "Hello world from pure controller! :D";
});