var app = angular.module("demoapp", ['ui.router']);

app.config(function($stateProvider){
  $stateProvider.state({
    name: 'home',
    url: '/',
    component: 'home'
  });
  $stateProvider.state({
    name: 'list',
    url: '/list',
    component: 'list',
    resolve: {
      people: function(StaffService) {
        return StaffService.getList();
      }
    }
  });
  $stateProvider.state({
    name: 'detail',
    url: '/staff/{name}',
    component: 'detail',
    resolve: {
      person: function(StaffService, $transition$) {
        return StaffService.getPerson($transition$.params().name);
      }
    }
  })
});