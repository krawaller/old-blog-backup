var app = angular.module("demoapp");

var people = {
  david: {
    name: "David Waller",
    framework: "Angular"
  },
  carl: {
    name: "Carl Mäsak",
    framework: "React"
  }
};

app.factory("StaffService",function(){
  return {
    getList: function(){
      return new Promise(function(resolve, reject){
        setTimeout(function(){
          resolve(Object.keys(people));
        },2000);
      });
    },
    getPerson: function(name){
      return new Promise(function(resolve, reject){
        setTimeout(function(){
          if (people[name]){
            resolve(people[name]);
          } else {
            reject("Unknown name: "+name);
          }
        },2000);
      });
    }
  };
})