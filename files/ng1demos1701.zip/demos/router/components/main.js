var app = angular.module("demoapp");

app.component("main",{
  template: `
    <h2>My super app</h2>
    <a ui-sref="home" ui-sref-active="active">Home</a>
    <a ui-sref="list" ui-sref-active="active">People</a>
    <ui-view></ui-view>
  `
})