var app = angular.module("demoapp");

app.component("detail",{
  bindings: { person: '<' },
  template: `
    <p>So, {{$ctrl.person.name}} prefers {{$ctrl.person.framework}}.</p>
  `
})