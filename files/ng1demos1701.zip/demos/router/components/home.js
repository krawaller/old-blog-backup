var app = angular.module("demoapp");

app.component("home", {
  template: `
    <p>Welcome to Edument!</p>
  `
})