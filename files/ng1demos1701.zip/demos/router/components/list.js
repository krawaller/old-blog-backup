var app = angular.module("demoapp");

app.component("list",{
  bindings: { people: '<' },
  template: `
    <p>These are the Edument employees:</p>
    <ul>
      <li ng-repeat="name in $ctrl.people">
        <a ui-sref="detail({ name: name })">{{name}}</a>
      </li>
    </ul>
  `
})