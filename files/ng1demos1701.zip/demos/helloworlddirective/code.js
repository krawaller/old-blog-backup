var app = angular.module("helloworld",[]);

app.directive('helloworld',function(){
  return {
    restrict: 'E', // use as Element
    link: function(scope){
      scope.message = "Hello world from component! :D";
    },
    template: '<strong>{{message}}</strong>'
  };
});
