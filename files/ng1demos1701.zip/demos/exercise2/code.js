
var app = angular.module("demoapp",[]);

app.controller("choreController", function($scope){
  $scope.chores = [
    {desc: "Do the dishes"},
    {desc: "Take out trash"},
    {desc: "Make the bed"}
  ];
  $scope.sortOptions = [
    {desc: "Description (ascending)", prop: "desc"},
    {desc: "Description (descending)", prop: "desc", rev: true},
    {desc: "Finished (ascending)", prop: "selected"},
    {desc: "Finished (descending)", prop: "selected", rev: true}
  ];
  $scope.selectedSortOpt = $scope.sortOptions[0];
  
  $scope.addChore = function(){
    $scope.chores.push({
      desc: $scope.newChoreDesc
    });
    $scope.newChoreDesc = '';
  };
});
