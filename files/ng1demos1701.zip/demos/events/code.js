
var app = angular.module("demoapp",[]);

var globalValue;

app.controller("ctrl1",function($scope,$rootScope,globalVal){
  $scope.sendMessage = function(){
    $scope.globalValue = globalValue;
    $rootScope.$broadcast("announcement",$scope.message);
    $scope.message = '';
  }
});

app.controller("ctrl2",function($scope){
  $scope.$on("announcement",function(e,data){
    $scope.receivedVal = data;
  })
});