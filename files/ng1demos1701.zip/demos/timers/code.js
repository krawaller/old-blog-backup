var app = angular.module("timerapp",[]);

app.component("servicetimer",{
  template: '<p>Seconds passed in servicetimer: {{$ctrl.count}}</p>',
  controller: function($interval){
    this.count = 0;
    $interval(function(){
      this.count += 1;
    }.bind(this),1000)
  }
});

app.component("digesttimer",{
  template: '<p>Seconds passed in digesttimer: {{$ctrl.count}}</p>',
  controller: function($scope){
    this.count = 0;
    setInterval(function(){
      this.count += 1;
      $scope.$digest();
    }.bind(this),1000)
  }
});