var app = angular.module("selectapp",[]);


app.component('selectDemo',{
  controller: function(){
    this.fruits = [
      {name:"Apple",tastiness:6},
      {name:"Cherry",tastiness:10},
      {name:"Strawberry",tastiness:4}
    ];
    this.selectedFruit = this.fruits[0];
  },
  template: `
    <select ng-model="$ctrl.selectedFruit">
      <option ng-repeat="f in $ctrl.fruits" ng-value="f">{{f.name}}</option>
    </select>
    <p>
      You have selected {{$ctrl.selectedFruit.name}}, which
      has a tastiness level of {{$ctrl.selectedFruit.tastiness}}
    </p>
  `
});