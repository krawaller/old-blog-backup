var app = angular.module('communicationapp');

app.component('childcomponent',{
  bindings: {
    static: '@',
    oneWay: '<',
    twoway: '=',
    code: '&'
  },
  controller: function(){
    this.count = 0;
    this.tellParent = function(){
      this.count += 1;
      this.code({message: "I can count to "+this.count+"!",foo:"bar"});
    }
  },
  template: `
    <h4>I am the child!</h4>
    <p>Static value from parent: {{$ctrl.static}}</p>
    <p>Dynamic one-way value from parent: <input ng-model="$ctrl.oneWay"></p>
    <p>Two-way value from parent: <input ng-model="$ctrl.twoway"></p>
    <p>Execute code from parent: <button ng-click="$ctrl.tellParent()">Click</button></p>
  `
})