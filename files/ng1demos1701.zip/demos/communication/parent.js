var app = angular.module('communicationapp');

app.component('parent',{
  controller: function(){
    this.listenToChild = function(msg){
      this.message = msg;
    }
  },
  template: `
    <h4>I am the parent!</h4>
    <p>One-way message to child: <input ng-model="$ctrl.oneway"></p>
    <p>Two-way message to child: <input ng-model="$ctrl.twoway"></p>
    <p>Last message from child via code: {{$ctrl.message}}</p>
    <hr>
    <childcomponent
      static="5"
      one-way="$ctrl.oneway"
      twoway="$ctrl.twoway"
      code="$ctrl.listenToChild(message)"></childcomponent>
  `
})