
var app = angular.module("demoapp",[]);

app.controller("choreController", ["$scope","choreService",function(apa, mage){
  mage.subscribe(function(data){
    apa.chores = data;
  });
  apa.addChore = function(){
    mage.addChore({
      desc: apa.newChoreDesc
    });
    apa.newChoreDesc = '';
  };
}]);

app.controller("overviewController", function($scope, choreService){
  choreService.subscribe(function(data){
    $scope.chores = data;
  });
});

app.factory("choreService",function($timeout){
  var chores = [
    {desc: "Do the dishes"},
    {desc: "Take out trash"},
    {desc: "Make the bed"}
  ];
  var subscribers = [];
  return {
    subscribe: function(cb){
      subscribers.push(cb);
      cb(angular.copy(chores));
    },
    addChore: function(obj){
      $timeout(function(){
        chores.push(obj);
        for(var i=0;i<subscribers.length;i++){
          subscribers[i](angular.copy(chores));
        }
      },3000);
    }
  };
});
