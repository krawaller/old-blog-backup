
var app = angular.module("compositionapp"); // getter!

app.component("myform", {
  controller: function(){
    this.submit = function(){
      this.submission = this.field;
      this.field = '';
    }
  },
  template: `
    <input ng-model="$ctrl.field"><button ng-click="$ctrl.submit()">Submit</button>
    <div>Submitted name: {{$ctrl.submission}}</div>
  `
});