var app = angular.module('app', ['ui.bootstrap']);

app.controller('QuoteController', function() {
  this.items = [
    {text:'Carpe noctem'},
    {text:'Dont eat yellow snow'},
    {text:'Choose the red pill'}
  ]
  this.currentPage = 1
  this.itemsPerPage = 3
  this.addNewItem = function(){
    this.items.push({text:this.newItemText});
    this.currentPage = Math.ceil(this.items.length / this.itemsPerPage);
    this.newItemText = '';
  }
});