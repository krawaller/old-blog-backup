var app = angular.module('app', ['ui.bootstrap']);

app.controller('QuoteController', ['$timeout', function($timeout) {
  this.items = [
    {text:'foobarbaz',status:'normal'},
    {text:'binbizmuu',status:'normal'},
    {text:'CTHULU IS COMING OMG OMG OMG',status:'normal'}
  ]
  this.currentPage = 1
  this.itemsPerPage = 3
  this.startEditItem = function(item,loopindex){
    item.newtext = item.text;
    item.status = 'editing';
  }
  this.confirmEditItem = function(item,loopindex){
    item.status = 'waiting';
    $timeout(function(){
      item.text = item.newtext;
      delete item.newtext;
      item.status = 'normal';
    },2000);
  }
  this.cancelEditItem = function(item,loopindex){
    item.status = 'normal';
    delete item.newtext;
  }
  this.deleteItem = function(item,loopindex){
    this.items = this.items.filter(function(i){return i!==item})
  }
  this.addNewItem = function(){
    this.items.push({text:this.newItemText,status:'normal'});
    this.currentPage = Math.ceil(this.items.length / this.itemsPerPage);
    this.newItemText = '';
  }
}]);