var app = angular.module("filterapp",[]);

app.filter('censor',function(){
  return function(str){
    str = str || '';
    if (str.match("darn")){
      return 'I have a filthy mouth but I love the lord'
    } else {
      return str;
    }
  }
});