var app = angular.module("formdemo",[]);

app.component('formdemo',{
  controller: function(){
    this.message = "Hello world from component! :D";
  },
  template: `
    <form>
      <input ng-model="$ctrl.name" minlength="5" required>
    </form>
  `
});
