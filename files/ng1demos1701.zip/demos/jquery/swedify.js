$.fn.swedify = function(){
  this.css({
    backgroundColor: "gold",
    border: "5px solid blue"
  });
  return this;
};