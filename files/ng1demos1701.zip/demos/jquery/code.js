var app = angular.module('jqueryapp',[]);

app.directive('swedify',function(){
  return {
    restrict: 'A',
    link: function(scope, element, attrs){
      element.swedify(); // element is jquery-wrapped
    }
  }
});
