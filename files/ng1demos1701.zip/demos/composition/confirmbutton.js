
var app = angular.module("compositionapp"); // getter!

app.component('confirm',{
  bindings: {
    disabled: '<',
    onConfirm: '&'
  },
  controller: function(){
    this.mode = 'waiting'; // will be 'waiting' or 'confirm'
    this.$onChanges = function(changesObj){
      if (changesObj.disabled.currentValue){
        this.mode = 'waiting'; // since we might be in confirming mode when disabled becomes true
      }
    }
    this.maybe = function(){
      this.mode = 'confirm';
    }
    this.changedmymind = function(){
      this.mode = 'waiting';
    }
    this.yesimsure = function(){
      this.mode = 'waiting';
      this.onConfirm(); // notifying parent
    }
  },
  template: `
    <button
      ng-if="$ctrl.mode!=='confirm'"
      ng-disabled="$ctrl.disabled"
      ng-click="$ctrl.maybe()">Submit</button>
    <span ng-if="$ctrl.mode==='confirm'">
      <button ng-click="$ctrl.yesimsure()">Confirm</button>
      <button ng-click="$ctrl.changedmymind()">Cancel</button>
    </span>
  `
});