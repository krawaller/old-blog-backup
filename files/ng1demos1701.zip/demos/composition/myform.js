
var app = angular.module("compositionapp"); // getter!

app.component("myform", {
  controller: function(){
    this.submit = function(){
      this.submission = this.field;
      this.field = '';
    }
  },
  template: `
    <input ng-model="$ctrl.field">
    <confirm
      on-confirm="$ctrl.submit()"
      disabled="!$ctrl.field"></confirm>
    <div>Submitted name: {{$ctrl.submission}}</div>
  `
});

