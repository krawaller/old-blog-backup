export declare var Math: any;
export declare var NaN: any;
