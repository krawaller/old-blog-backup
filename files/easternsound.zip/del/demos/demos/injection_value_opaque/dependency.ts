import { OpaqueToken } from '@angular/core'

export const finalAnswerToken = new OpaqueToken('answer')

export const finalAnswerVal = 42