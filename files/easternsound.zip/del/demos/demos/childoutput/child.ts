import {Component,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'child',
  template: `
    <button (click)="increase()">Say {{count+1}}</button>
  `
})
export class ChildComponent {
  count = 0
  increase(){
    this.count++
    this.say.emit(this.count)
  }
  @Output() say = new EventEmitter<number>()
}
