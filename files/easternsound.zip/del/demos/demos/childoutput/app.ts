import {Component,ViewChild} from '@angular/core'

@Component({
  selector: 'app',
  template: `
    {{response}}
    <hr>
    <child (say)="hear($event)"></child>
  `
})
export class AppComponent {
  response = 'So, can you count, my child?'
  hear(num){
    this.response = `And what comes after ${num}?`;
  }
}
