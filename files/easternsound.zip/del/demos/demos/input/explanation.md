Showing two-way databinding in a text field without using `ngModel`.

Since we're binding to the `change` event, this will only update when the input loses focus.