import {Component} from '@angular/core'
import {FormControl} from '@angular/forms'

@Component({
  selector: 'app',
  template: `
    <input [formControl]="field">
    <button (click)="readFromInput()">click!</button>
    <p>Text: {{fetchedValue}}</p>
  `
})
export class AppComponent {
  field: FormControl = new FormControl('')
  fetchedValue: string
  readFromInput() {
    console.log("FIELD",this.field.valueChanges)
    this.fetchedValue = this.field.value;
  }
}
