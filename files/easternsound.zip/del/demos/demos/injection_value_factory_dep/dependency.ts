import { OpaqueToken } from '@angular/core'

export const finalAnswerToken = new OpaqueToken('answer')

export const finalAnswerFactory = dep => dep.bar