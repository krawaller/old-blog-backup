Stolen from the A2 docs.

By putting `#box` on the input tag, we can reference that element elsewhere in the template.

The dummy binding to the `keyup` event is to make A2 update the bindings on events, otherwise it wouldn't.