import {Component,ElementRef} from '@angular/core';

@Component({
  selector: 'app',
  template: `
    <swedify>I am Swedish!</swedify>
    `
})
export class AppComponent {}
