export default class Dependency2 {
  bar: string = 'baz'
}